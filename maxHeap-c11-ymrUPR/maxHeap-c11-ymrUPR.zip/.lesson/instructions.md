## Binary heap usando nodos enlazados

El propósito de este ejercicio es implementar un max-heap usando nodos enlazados, en vez de usar un arreglo (que es lo que usan los heaps normalmente). El max-heap debe apoyar las operaciones de insertar (usando percolate up), remover la raíz (utilizando percolate down) y acceder el valor de la raiz. Las operaciones de insertar y remover han de ser O(logN), donde N es el número de nodos. La operación de acceder el valor debe ser O(1). 

Cada nodo del max-heap será un objeto de la clase `BHNode`. Nota que cada `BHNode` tiene un puntero a su padre, esto para facilitar el recorrido desde una hoja hacia la raíz (como en el caso de percolate up).

**Preguntas frecuentes**
* *¿Puedo añadir otros data members?*  - Si, pero solo data members sencillos de complejidad de espacio O(1).

* *¿Por qué implementar un heap de esta manera, si nadie lo hace así?*: Quiero que practiquen con estructuras enlazadas, ya que no hicimos ejercicios de implementación con *binary search trees*

### Recomendaciones:

* usa la función de visualizar el arbol (`toString`) para que valides que las funciones hacen lo esperado!


### Entregables

* Completa todas las funciones necesarias y crea pruebas en el `main` que demuestren que el max-heap está funcionando. Puedes usar la función `preOrder` para verificar si estas obteniendo el max-heap correcto.
* Haz submit a través de replit 